﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheMinx
{
    class RunningRace
    {
        public string Dog { get; set; }
        public int Box { get; set; }
        public double VicPrice { get; set; }
        public double NswPrice { get; set; }
        public double QldPrice { get; set; }
        public double VicPlace { get; set; }
        public double NswPlace { get; set; }
        public double QldPlace { get; set; }
        public string Tip { get; set; }
        public double MyPrice { get; set; }
        public double BetAmt { get; set; }
        public string Status { get; set; }
        public int RaceNum { get; set; }

        public int meetingCode { get; set; }
        public string qldMeetingCode { get; set; }
    }
}
