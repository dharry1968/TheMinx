﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TheMinx.Tatts.Data.Data.Tote;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using TheMinx.wsTabBetting;
using System.Data.SqlClient;

namespace TheMinx
{
    public class Bet
    {
        Utils utils = new Utils();
        Globals global = new Globals();
        string live = "No";

        public void PlaceBetQld(string RaceID, int selection, double betamt, int racenum, string meetingcode)
        {
            Console.WriteLine("Placed Bet QLD");
            ToteBet bet = new ToteBet();
            bet.BetType = "WN"; //Win Only - for WIn and Place code is WP
            bet.MeetingCode = meetingcode;
            bet.RaceNumber = racenum;
            ToteSelection sel1 = GetToteSelection(selection.ToString());
            bet.Selections.Add(sel1);
            betamt = betamt * 2;
            betamt = Math.Round(betamt, MidpointRounding.AwayFromZero);
            betamt = betamt / 2;
            bet.WinInvestment = betamt;
            bet.PlaceInvestment = betamt;
            ToteBetRequest request = new ToteBetRequest();
            request.AuthenticationToken = Globals.QldAuth;

            request.Bets.Add(bet);
            if (Globals.BettingEnabled)
            {
                request.Sell = true;
                live = "Yes";
            }
            else
            {
                request.Sell = false;
                live = "No";
            }

            string requestJSON = JsonConvert.SerializeObject(request);
            string responseJSON = TattsUtils.CallAPI("tote/bet/", requestJSON, true, "POST");

            ToteBetResponse response = null;

            if (!string.IsNullOrEmpty(responseJSON))
            {
                response = JsonConvert.DeserializeObject<ToteBetResponse>(responseJSON);
            }

            if (response != null && response.Bets.Count > 0)
            {
                ToteTicket ticket = response.Bets[0].Ticket;
                if (ticket.Summary == "Invalid Meeting Code")
                {
                    Console.WriteLine("Invalid Meeting Code:" + meetingcode);

                }
                Console.WriteLine(string.Format("[Success QLD: Live:{0} {1}, Actual Cost: ${2}] {3} Runner:{4}",live , ticket.Success, ticket.ActualSpend, ticket.Summary,selection.ToString().Replace("'","")));
                WriteStatus(string.Format("[Success QLD: Live:{0} {1}, Actual Cost: ${2}] {3} {4} Runner:{5}",live , ticket.Success, ticket.ActualSpend, ticket.Summary, DateTime.Now.ToString("hh:MM:ss"),selection.ToString().Replace("'","")), Globals.BettingEnabled, RaceID, selection.ToString(), "QLD", "BetStatus",betamt.ToString());
                utils.WriteLog(string.Format("[Success QLD: Live:{0} {1}, Actual Cost: ${2}] {3} Runner:{4} Race ID:{5} Time:{6}", live, ticket.Success, ticket.ActualSpend, ticket.Summary, selection.ToString().Replace("'", ""),RaceID,DateTime.Now.ToString("hh:mm:ss")));
//                mainfrm.AppendTextBox(string.Format("[Success QLD: {0}, Actual Cost: ${1}] {2} {3}", ticket.Success, ticket.ActualSpend, ticket.Summary, DateTime.Now.ToString("hh:MM:ss")));
               
            }
            else
            {
                Console.WriteLine("Bet Failed (Unknown Reason)");
                WriteStatus("Bet Failed QLD (Unknown Reason)", Globals.BettingEnabled, RaceID, selection.ToString(), "QLD", "BetStatus","");
            }
            Console.WriteLine("QLD After Bet:" + RaceID + " - " + DateTime.Now.ToString("hh:MM:ss"));
            utils.GetQldBal();
        }

        protected ToteSelection GetToteSelection(string selectionsString)
        {
            ToteSelection selections = new ToteSelection();

            selections.Field = false;
            selections.Runners = new List<int>();

            selectionsString = Regex.Replace(selectionsString, @"\s+", " ");
            selectionsString = selectionsString.Replace(" ", ",");
            selectionsString = selectionsString.Replace("/", ",");
            selectionsString = selectionsString.Replace(@"\", ",");

            string[] runners = selectionsString.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string runner in runners)
            {
                if (runner.ToUpper() == "F")
                {
                    selections.Field = true;
                    selections.Runners = new List<int>();

                    break;
                }
                else
                {
                    int runnerNumber = ParserUtils.String_GetIntValue(runner, 0);

                    if (runnerNumber > 0 && runnerNumber <= 24)
                    {
                        selections.Runners.Add(runnerNumber);
                    }
                }
            }

            if (selections.Field || selections.Runners.Count >= 1)
            {
                return selections;
            }
            else
            {
                return null;
            }
        }

        public void PlaceBetVic(string RaceID, int selection, double betamt, int racenum, int meetingcode, string Runner)
        {
            Console.WriteLine("Placed Bet VIC");

            apiMeta meta = new apiMeta();
            meta.deviceId = Globals.DeviceID;
            meta.requestChannel = Globals.VicChan;
            meta.jurisdictionId = Globals.VicJury;
            meta.deviceIdSpecified = true;
            meta.usernamePasswordToken = Globals.VicAuth;
            bool yesterday = false;
            TimeSpan tme = DateTime.Now.TimeOfDay;
            if (tme.Ticks < 26000)
            {
                yesterday = true;
            }

            wsTabBetting.BettingServiceClient bet = new BettingServiceClient();

            //            MessageViewerInspector msgViewer = new MessageViewerInspector();
            //            bet.Endpoint.Behaviors.Add(msgViewer);

            bettingRequest betReq = new bettingRequest();
            betDetailsReq betDetReq = new betDetailsReq();

            List<legDetailsReq> leglist = new List<legDetailsReq>();
            List<betSelection> sellist = new List<betSelection>();
            List<betAmount> betamtlist = new List<betAmount>();
            List<betDetailsReq> betdetaillist = new List<betDetailsReq>();

            betSelection sel = new betSelection();
            sel.selectionNumber = selection.ToString();
            sel.selectionName = Runner;
            sel.selectionSeparator = " ";
            sellist.Add(sel);

            legDetailsReq leg = new legDetailsReq();
            leg.prodCode = 1; // 12 for each way - 1 for Win only
            leg.propositionNumber = 0;
            leg.raceNumber = racenum;
            leg.selectionList = sellist.ToArray();
            leglist.Add(leg);

            betAmount betAmt = new betAmount();
            betamt = betamt * 2;
            betamt = Math.Round(betamt, MidpointRounding.AwayFromZero);
            betamt = betamt / 2;
            betAmt.amountInvested = betamt;
            //            betAmt.amountInvested = 5;
            betAmt.returnsPerBet = "0";
            betamtlist.Add(betAmt);

            betDetReq.betType = "Parimutuel";
            betDetReq.betAmountList = betamtlist.ToArray();
            betDetReq.legList = leglist.ToArray();
            betDetReq.allUpFormula = "0";
            betDetReq.acceptPartial = 0;
            betDetReq.accumulatorBet = false;
            betDetReq.betRefId = 0;
            //            betDetReq.scheduledType = 1;
            betDetReq.fixedOddsProdCode = 0;
            betDetReq.flexiBet = false;
            betDetReq.mystery = false;
            betDetReq.notifyMethod = 0;
            betDetReq.ordinalNumber = 1;
            betDetReq.scheduledType = 3;

            betDetReq.meetingCode = meetingcode;

            if (yesterday)
            {
                betDetReq.meetingDate = DateTime.Now.AddDays(-1).Date;
            }
            else
            {
                betDetReq.meetingDate = DateTime.Now.Date;
            }
            betDetReq.meetingDateSpecified = true;
            betDetReq.multiParlayFormula = null;
            betdetaillist.Add(betDetReq);

            betReq.betDetailsRequestList = betdetaillist.ToArray();

            bettingResponse resp = null;

            if (Globals.BettingEnabled)
            {
                resp = bet.placeBet(meta, betReq);
                live = "Yes";
            }
            else
            {
                resp = bet.validateBet(meta, betReq);
                live = "No";
            }

            string response = resp.betDetailsResponseList[0].statusMessage;

            if (response == "SUCCESS")
            {
                Console.WriteLine(string.Format("[Success VIC: Live:{0} {1}, Actual Cost: ${2}] Balance: {3} Runner: {4}", live, resp.betDetailsResponseList[0].statusMessage, resp.betDetailsResponseList[0].amountTicket, resp.betDetailsResponseList[0].accountBalance,Runner.Replace("'","")));
                WriteStatus(string.Format("[Success VIC: Live:{0} {1}, Actual Cost: ${2}] Balance: {3} {4} Runner: {5}", live, resp.betDetailsResponseList[0].statusMessage, resp.betDetailsResponseList[0].amountTicket, resp.betDetailsResponseList[0].accountBalance, DateTime.Now.ToString("hh:MM:ss"),Runner.Replace("'","")), Globals.BettingEnabled, RaceID, selection.ToString(), "VIC", "BetStatus",betamt.ToString());
                utils.WriteLog(string.Format("[Success VIC: Live:{0} {1}, Actual Cost: ${2}] Balance: {3} Runner: {4} Race ID:{5} Time:{6}", live, resp.betDetailsResponseList[0].statusMessage, resp.betDetailsResponseList[0].amountTicket, resp.betDetailsResponseList[0].accountBalance, Runner.Replace("'", ""),RaceID,DateTime.Now.ToString("hh:mm:ss")));
//                mainfrm.AppendTextBox(string.Format("[Success VIC: {0}, Actual Cost: ${1}] Balance: {2} {3}", resp.betDetailsResponseList[0].statusMessage, resp.betDetailsResponseList[0].amountTicket, resp.betDetailsResponseList[0].accountBalance, DateTime.Now.ToString("hh:MM:ss")));
            }
            else
            {
                Console.WriteLine("Bet Failed VIC - {0}", resp.betDetailsResponseList[0].statusMessage);
                utils.WriteLog(string.Format("Bet Failed VIC - {0}", resp.betDetailsResponseList[0].statusMessage));
                WriteStatus(string.Format("[Bet Failed VIC: {0}]", resp.betDetailsResponseList[0].statusMessage), Globals.BettingEnabled, RaceID, selection.ToString(), "VIC", "BetStatus","");
                utils.WriteLog(string.Format("[Bet Failed VIC: Live:{0} {1}, Actual Cost: ${2}] Balance: {3} Runner: {4} Race ID:{5} Time:{6}", live, resp.betDetailsResponseList[0].statusMessage, resp.betDetailsResponseList[0].amountTicket, resp.betDetailsResponseList[0].accountBalance, Runner.Replace("'", ""), RaceID, DateTime.Now.ToString("hh:mm:ss")));
//                mainfrm.AppendTextBox(string.Format("[Failed: {0}, Actual Cost: ${1}] Balance: {2}", resp.betDetailsResponseList[0].statusMessage, resp.betDetailsResponseList[0].amountTicket, resp.betDetailsResponseList[0].accountBalance));
            }
        }

        public void PlaceBetNsw(string RaceID, int selection, double betamt, int racenum, int meetingcode, string Runner)
        {
            Console.WriteLine("Placed Bet NSW");

            apiMeta meta = new apiMeta();
            meta.deviceId = Globals.DeviceID;
            meta.requestChannel = Globals.NswChan;
            meta.jurisdictionId = Globals.NswJury; ;
            meta.deviceIdSpecified = true;
            meta.usernamePasswordToken = Globals.NswAuth;
            bool yesterday = false;
            TimeSpan tme = DateTime.Now.TimeOfDay;
            if (tme.Ticks < 26000)
            {
                yesterday = true;
            }

            wsTabBetting.BettingServiceClient bet = new BettingServiceClient();

            //            MessageViewerInspector msgViewer = new MessageViewerInspector();
            //            bet.Endpoint.Behaviors.Add(msgViewer);

            bettingRequest betReq = new bettingRequest();
            betDetailsReq betDetReq = new betDetailsReq();

            List<legDetailsReq> leglist = new List<legDetailsReq>();
            List<betSelection> sellist = new List<betSelection>();
            List<betAmount> betamtlist = new List<betAmount>();
            List<betDetailsReq> betdetaillist = new List<betDetailsReq>();

            betSelection sel = new betSelection();
            sel.selectionNumber = selection.ToString();
            sel.selectionName = Runner;
            sel.selectionSeparator = " ";
            sellist.Add(sel);

            legDetailsReq leg = new legDetailsReq();
            leg.prodCode = 1; //12 for eachway, 1 for win only
            leg.propositionNumber = 0;
            leg.raceNumber = racenum;
            leg.selectionList = sellist.ToArray();
            leglist.Add(leg);

            betAmount betAmt = new betAmount();
            betamt = betamt * 2;
            betamt = Math.Round(betamt, MidpointRounding.AwayFromZero);
            betamt = betamt / 2;

            betAmt.amountInvested = betamt;
            //            betAmt.amountInvested = 5;
            betAmt.returnsPerBet = "0";
            betamtlist.Add(betAmt);

            betDetReq.betType = "Parimutuel";
            betDetReq.betAmountList = betamtlist.ToArray();
            betDetReq.legList = leglist.ToArray();
            betDetReq.allUpFormula = "0";
            betDetReq.acceptPartial = 0;
            betDetReq.accumulatorBet = false;
            betDetReq.betRefId = 0;
            betDetReq.scheduledType = 3;
            betDetReq.fixedOddsProdCode = 0;
            betDetReq.flexiBet = false;
            betDetReq.mystery = false;
            betDetReq.notifyMethod = 0;
            betDetReq.ordinalNumber = 1;
            betDetReq.meetingCode = meetingcode;
            if (yesterday)
            {
                betDetReq.meetingDate = DateTime.Now.AddDays(-1).Date;
            }
            else
            {
                betDetReq.meetingDate = DateTime.Now.Date;
            }
            betDetReq.meetingDateSpecified = true;
            betdetaillist.Add(betDetReq);

            betReq.betDetailsRequestList = betdetaillist.ToArray();

            bettingResponse resp = null;
            if (Globals.BettingEnabled)
            {
                resp = bet.placeBet(meta, betReq);
                live  = "Yes";
            }
            else
            {
                resp = bet.validateBet(meta, betReq);
                live = "No";
            }

            string response = resp.betDetailsResponseList[0].statusMessage;

            if (response == "SUCCESS")
            {
                Console.WriteLine(string.Format("[Success NSW: Live:{0} {1}, Actual Cost: ${2}] Balance: {3} Runner: {4}", live, resp.betDetailsResponseList[0].statusMessage, resp.betDetailsResponseList[0].amountTicket, resp.betDetailsResponseList[0].accountBalance,Runner));
                WriteStatus(string.Format("[Success NSW: Live:{0} {1}, Actual Cost: ${2}] Balance: {3} {4} Runner: {5}", live, resp.betDetailsResponseList[0].statusMessage, resp.betDetailsResponseList[0].amountTicket, resp.betDetailsResponseList[0].accountBalance, DateTime.Now.ToString("hh:MM:ss"),Runner.Replace("'","")), Globals.BettingEnabled, RaceID, selection.ToString(), "NSW", "BetStatus",betamt.ToString());
                utils.WriteLog(string.Format("[Success NSW: Live:{0} {1}, Actual Cost: ${2}] Balance: {3} Runner: {4} Race ID:{5} Time:{6}", live, resp.betDetailsResponseList[0].statusMessage, resp.betDetailsResponseList[0].amountTicket, resp.betDetailsResponseList[0].accountBalance, Runner.Replace("'", ""), RaceID, DateTime.Now.ToString("hh:mm:ss")));
//                mainfrm.AppendTextBox(string.Format("[Success NSW: {0}, Actual Cost: ${1}] Balance: {2} {3}", resp.betDetailsResponseList[0].statusMessage, resp.betDetailsResponseList[0].amountTicket, resp.betDetailsResponseList[0].accountBalance, DateTime.Now.ToString("hh:MM:ss")));
            }
            else
            {
                Console.WriteLine("Bet Failed NSW - {0}", resp.betDetailsResponseList[0].statusMessage);
                utils.WriteLog(string.Format("Bet Failed NSW - {0}", resp.betDetailsResponseList[0].statusMessage));
                WriteStatus(string.Format("[Bet Failed NSW: {0}]", resp.betDetailsResponseList[0].statusMessage), Globals.BettingEnabled, RaceID, selection.ToString(), "NSW", "BetStatus","");
                utils.WriteLog(string.Format("[Bet Failed NSW: Live:{0} {1}, Actual Cost: ${2}] Balance: {3} Runner: {4} Race ID:{5} Time:{6}", live, resp.betDetailsResponseList[0].statusMessage, resp.betDetailsResponseList[0].amountTicket, resp.betDetailsResponseList[0].accountBalance, Runner.Replace("'", ""), RaceID, DateTime.Now.ToString("hh:mm:ss")));
//                mainfrm.AppendTextBox(string.Format("[Failed: {0}, Actual Cost: ${1}] Balance: {2}", resp.betDetailsResponseList[0].statusMessage, resp.betDetailsResponseList[0].amountTicket, resp.betDetailsResponseList[0].accountBalance));
            }
        }

        private void WriteStatus(string status, bool livebetting, string RaceID, string box, string State, string Field, string BetAmount)
        {
            string live = string.Empty;
            if (!livebetting)
            {
                live = "FALSE";
            }
            else
            {
                live = "TRUE";
            }
            
            global.dbCon = new SqlConnection(Globals.dbConString);
            string updstr = "update LivePrices set " + Field + " = '" + status + "', BetAmount = '" + BetAmount + "', BetState = '" + State + "' where RaceID = '" + RaceID + "' and RaceDate = '" + DateTime.Now.ToString("yyyyMMdd") + "' and Box = '" + box + "'";
            global.dbCon.Open();
            SqlCommand upd = new SqlCommand(updstr, global.dbCon);
            upd.ExecuteNonQuery();
            global.dbCon.Close();
        }
    }
}
