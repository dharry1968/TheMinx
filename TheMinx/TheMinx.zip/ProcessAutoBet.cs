﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheMinx
{
    public class ProcessAutoBet
    {
        //public DataGridView dgRace { get; set; }
        public bool pctOn { get; set; }
        public int raceNum { get; set; }
        public bool useRatingBetAmount { get; set; }
        public bool betOnVic { get; set; }
        public bool betOnNsw { get; set; }
        public bool betOnQld { get; set; }
        public bool betOnAll { get; set; }
        public double betPct { get; set; }
        public double betToWin { get; set; }

        public double bestPrice { get; set; }
        public double bestPct { get; set; }
        public double vicPrice { get; set; }
        public double nswPrice { get; set; }
        public double qldPrice { get; set; }
        public double myPrice { get; set; }
        public double ratingBetAmt { get; set; }
        public double calAmt { get; set; }
        public int selection { get; set; }
        public string runner { get; set; }
        public string raceID { get; set; }
        public int meetingCode { get; set; }
        public string qldMeetingCode { get; set; }
        public string tip { get; set; }

        //public void ProcessAutoBetNow()
        //{
        //    if (!Globals.BettingEnabled) return;

        //    decimal totalBal = Globals.VicBal + Globals.NswBal + Globals.QldBal;

        //    if (totalBal > Globals.StopWin) return;
        //    if (totalBal < Globals.StopLoss) return;

        //    foreach (DataGridViewRow row in dgRace.Rows)
        //    {
        //        double bestPrice = 0;

        //        try
        //        {
        //            bestPrice = Convert.ToDouble(row.Cells[3].Value);
        //        }
        //        catch
        //        {
        //            bestPrice = 0;
        //        }

        //        double bestPct = 0;

        //        try
        //        {
        //            bestPct = Convert.ToDouble(row.Cells[5].Value);
        //        }
        //        catch
        //        {
        //            bestPct = 0;
        //        }

        //        double vicPrice = 0;

        //        try
        //        {
        //            vicPrice = Convert.ToDouble(row.Cells[6].Value);
        //        }
        //        catch
        //        {
        //            vicPrice = 0;
        //        }

        //        double nswPrice = 0;

        //        try
        //        {
        //            nswPrice = Convert.ToDouble(row.Cells[8].Value);
        //        }
        //        catch
        //        {
        //            nswPrice = 0;
        //        }

        //        double qldPrice = 0;

        //        try
        //        {
        //            qldPrice = Convert.ToDouble(row.Cells[10].Value);
        //        }
        //        catch
        //        {
        //            qldPrice = 0;
        //        }

        //        double myPrice = 0;

        //        try
        //        {
        //            myPrice = Convert.ToDouble(row.Cells[12].Value);
        //        }
        //        catch
        //        {
        //            myPrice = 0;
        //        }

        //        double ratingBetAmt = 0;

        //        try
        //        {
        //            ratingBetAmt = Convert.ToDouble(row.Cells[13].Value);
        //        }
        //        catch
        //        {
        //            ratingBetAmt = 0;
        //        }

        //        double calAmt = 0;

        //        int selection = Convert.ToInt32(row.Cells[0].Value);
        //        string runner = row.Cells[1].Value.ToString();
        //        string raceID = row.Cells[15].Value.ToString();
        //        int meetingCode = Convert.ToInt32(row.Cells[16].Value.ToString());
        //        string qldMeetingCode = row.Cells[17].Value.ToString();
        //        string tip = row.Cells[14].Value.ToString();
        //        Bet bet = new Bet();

        //        if (!pctOn)//Use Price 
        //        {
        //            if (vicPrice > myPrice && vicPrice > 0 && tip != "" && (betOnVic || betOnAll))
        //            {
        //                if (useRatingBetAmount)
        //                {
        //                    bet.PlaceBetVic(raceID, selection, ratingBetAmt, raceNum, meetingCode, runner);
        //                }
        //                else
        //                {
        //                    calAmt = betToWin / (vicPrice - 1);
        //                    bet.PlaceBetVic(raceID, selection, calAmt, raceNum, meetingCode, runner);
        //                }
        //            }

        //            if (nswPrice > myPrice && nswPrice > 0 && tip != "" && (betOnNsw || betOnAll))
        //            {
        //                if (useRatingBetAmount)
        //                {
        //                    bet.PlaceBetNsw(raceID, selection, ratingBetAmt, raceNum, meetingCode, runner);
        //                }
        //                else
        //                {
        //                    calAmt = betToWin / (nswPrice - 1);
        //                    bet.PlaceBetNsw(raceID, selection, calAmt, raceNum, meetingCode, runner);
        //                }
        //            }

        //            if (qldPrice > myPrice && qldPrice > 0 && tip != "" && (betOnQld || betOnAll))
        //            {
        //                if (useRatingBetAmount)
        //                {
        //                    bet.PlaceBetQld(raceID, selection, ratingBetAmt, raceNum, qldMeetingCode);
        //                }
        //                else
        //                {
        //                    calAmt = betToWin / (qldPrice - 1);
        //                    bet.PlaceBetQld(raceID, selection, calAmt, raceNum, qldMeetingCode);
        //                }
        //            }
        //        }
        //        else//Use % Best Price applied
        //        {
        //            if (bestPct <= betPct)
        //            {
        //                if (vicPrice == bestPrice && vicPrice > 0)
        //                {
        //                    if (!useRatingBetAmount)
        //                    {
        //                        calAmt = betToWin / (vicPrice - 1);
        //                        bet.PlaceBetVic(raceID, selection, calAmt, raceNum, meetingCode, runner);
        //                    }
        //                    else
        //                    {
        //                        bet.PlaceBetVic(raceID, selection, ratingBetAmt, raceNum, meetingCode, runner);
        //                    }
        //                }

        //                if (nswPrice == bestPrice && nswPrice > 0)
        //                {
        //                    if (!useRatingBetAmount)
        //                    {
        //                        calAmt = betToWin / (nswPrice - 1);
        //                        bet.PlaceBetNsw(raceID, selection, calAmt, raceNum, meetingCode, runner);
        //                    }
        //                    else
        //                    {
        //                        bet.PlaceBetNsw(raceID, selection, ratingBetAmt, raceNum, meetingCode, runner);
        //                    }
        //                }

        //                if (qldPrice == bestPrice && qldPrice > 0)
        //                {
        //                    if (!useRatingBetAmount)
        //                    {
        //                        calAmt = betToWin / (qldPrice - 1);
        //                        bet.PlaceBetQld(raceID, selection, calAmt, raceNum, qldMeetingCode);
        //                    }
        //                    else
        //                    {
        //                        bet.PlaceBetQld(raceID, selection, ratingBetAmt, raceNum, qldMeetingCode);
        //                    }
        //                }
        //            }
        //        }
        //    }
        //}

        public void ProcessAutoBetNow()
        {
//            if (!Globals.BettingEnabled) return;

            decimal totalBal = Globals.VicBal + Globals.NswBal + Globals.QldBal;

            if (totalBal > Globals.StopWin) return;
            if (totalBal < (Globals.StopLoss * -1)) return;

            Bet bet = new Bet();

            if (!pctOn)//Use Price 
            {
                if (vicPrice > myPrice && vicPrice > 0 && tip != "" && (betOnVic || betOnAll) && Globals.VicEnable)
                {
                    if (useRatingBetAmount)
                    {
                        bet.PlaceBetVic(raceID, selection, ratingBetAmt, raceNum, meetingCode, runner);
                    }
                    else
                    {
                        calAmt = betToWin / (vicPrice);
                        bet.PlaceBetVic(raceID, selection, calAmt, raceNum, meetingCode, runner);
                    }
                }

                if (nswPrice > myPrice && nswPrice > 0 && tip != "" && (betOnNsw || betOnAll) && Globals.NswEnable)
                {
                    if (useRatingBetAmount)
                    {
                        bet.PlaceBetNsw(raceID, selection, ratingBetAmt, raceNum, meetingCode, runner);
                    }
                    else
                    {
                        calAmt = betToWin / (nswPrice);
                        bet.PlaceBetNsw(raceID, selection, calAmt, raceNum, meetingCode, runner);
                    }
                }

                if (qldPrice > myPrice && qldPrice > 0 && tip != "" && (betOnQld || betOnAll) && Globals.QldEnable)
                {
                    if (useRatingBetAmount)
                    {
                        bet.PlaceBetQld(raceID, selection, ratingBetAmt, raceNum, qldMeetingCode);
                    }
                    else
                    {
                        calAmt = betToWin / (qldPrice);
                        bet.PlaceBetQld(raceID, selection, calAmt, raceNum, qldMeetingCode);
                    }
                }
            }
            else//Use % Best Price applied
            {
                if (bestPct <= Globals.BetPct)
                {
                    if (vicPrice == bestPrice && vicPrice > 0 && Globals.VicEnable)
                    {
                        if (!useRatingBetAmount)
                        {
                            calAmt = betToWin / (vicPrice);
                            bet.PlaceBetVic(raceID, selection, calAmt, raceNum, meetingCode, runner);
                        }
                        else
                        {
                            bet.PlaceBetVic(raceID, selection, ratingBetAmt, raceNum, meetingCode, runner);
                        }
                    }

                    if (nswPrice == bestPrice && nswPrice > 0 && Globals.NswEnable)
                    {
                        if (!useRatingBetAmount)
                        {
                            calAmt = betToWin / (nswPrice);
                            bet.PlaceBetNsw(raceID, selection, calAmt, raceNum, meetingCode, runner);
                        }
                        else
                        {
                            bet.PlaceBetNsw(raceID, selection, ratingBetAmt, raceNum, meetingCode, runner);
                        }
                    }

                    if (qldPrice == bestPrice && qldPrice > 0 && Globals.QldEnable)
                    {
                        if (!useRatingBetAmount)
                        {
                            calAmt = betToWin / (qldPrice);
                            bet.PlaceBetQld(raceID, selection, calAmt, raceNum, qldMeetingCode);
                        }
                        else
                        {
                            bet.PlaceBetQld(raceID, selection, ratingBetAmt, raceNum, qldMeetingCode);
                        }
                    }
                }
            }
        }
    }
}
